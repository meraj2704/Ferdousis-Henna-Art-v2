import Loader from "@/components/share/Loader";
import React from "react";

const Loading = () => {
  return (
    <div>
      {/* <Loader /> */}
    </div>
  );
};

export default Loading;
