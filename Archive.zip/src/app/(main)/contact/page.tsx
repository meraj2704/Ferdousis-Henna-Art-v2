import ContactUsPage from "@/components/contact/ContactUsPage";
import React from "react";

const page = () => {
  return (
    <div>
      <ContactUsPage />
    </div>
  );
};

export default page;
