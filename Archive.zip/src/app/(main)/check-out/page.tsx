import CheckoutPage from '@/components/checkOut/CheckOutPage';
import React from 'react';

const page = () => {
    return (
        <div>
            <CheckoutPage/>
        </div>
    );
};

export default page;