import CartPage from "@/components/cart/cartPage/CartPage";
import React from "react";

const page = () => {
  return (
    <>
      <CartPage />
    </>
  );
};

export default page;
