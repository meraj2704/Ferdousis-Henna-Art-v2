import About from "@/components/about/About";
import React from "react";

const page = () => {
  return (
    <div>
      <About />
    </div>
  );
};

export default page;
