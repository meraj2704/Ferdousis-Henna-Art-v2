import LandingPage from "@/components/LandingPage/Hero";
import Hero from "@/components/LandingPage/Hero";

export default function Home() {
  return (
    <main>
      <LandingPage />
    </main>
  );
}
