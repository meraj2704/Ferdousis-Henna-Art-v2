import SingleProduct from "@/components/products/SingleProduct";
import React from "react";

const page = () => {
  return (
    <>
      <SingleProduct />
    </>
  );
};

export default page;
