import Products from "@/components/products/Products";
import React from "react";

const page = () => {
  return (
    <div>
      <Products />
    </div>
  );
};

export default page;
