import { Messages } from "@/components/admin/messages/Messages";
import React from "react";

const page = () => {
  return (
    <div>
      <Messages />
    </div>
  );
};

export default page;
