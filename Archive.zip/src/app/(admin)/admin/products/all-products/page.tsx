import { AllProducts } from "@/components/admin/products/all-products/AllProducts";
import React from "react";

const page = () => {
  return (
    <div>
      <AllProducts />
    </div>
  );
};

export default page;
