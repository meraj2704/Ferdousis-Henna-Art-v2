import EditProduct from "@/components/admin/products/editProduct/EditProduct";
import React from "react";

const page = () => {
  return (
    <div>
      <EditProduct />
    </div>
  );
};

export default page;
