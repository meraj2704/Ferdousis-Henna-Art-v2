import AddProductForm from "@/components/admin/products/addProducts/AddProducts";
import React from "react";
const page = () => {
  return (
    <div>
      <AddProductForm />
    </div>
  );
};

export default page;
