import AddPhoto from "@/components/admin/photo-gallery/AddPhoto";
import React from "react";

const page = () => {
  return (
    <div>
      <AddPhoto />
    </div>
  );
};

export default page;
