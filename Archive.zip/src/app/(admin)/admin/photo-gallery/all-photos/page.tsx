import { AllPhotos } from "@/components/admin/photo-gallery/AllPhotos";
import React from "react";

const page = () => {
  return (
    <div>
      <AllPhotos />
    </div>
  );
};

export default page;
