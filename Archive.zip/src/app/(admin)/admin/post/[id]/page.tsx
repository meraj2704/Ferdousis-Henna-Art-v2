import PostDetails from "@/components/admin/post/PostDetails";
import React from "react";

const page = () => {
  return (
    <div>
      <PostDetails />
    </div>
  );
};

export default page;
