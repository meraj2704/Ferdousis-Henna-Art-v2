import AddPost from "@/components/admin/post/AddPost";
import React from "react";

const page = () => {
  return (
    <div>
      <AddPost />
    </div>
  );
};

export default page;
