import EditPost from "@/components/admin/post/EditPost";
import React from "react";

const page = () => {
  return (
    <div>
      <EditPost />
    </div>
  );
};

export default page;
