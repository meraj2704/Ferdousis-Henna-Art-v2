import { AllPosts } from "@/components/admin/post/AllPost";
import React from "react";

const page = () => {
  return (
    <div>
      <AllPosts />
    </div>
  );
};

export default page;
