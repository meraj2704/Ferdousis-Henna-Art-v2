import OrderDetails from "@/components/admin/orders/OrderDetails";
import React from "react";

const page = () => {
  return (
    <div>
      <OrderDetails />
    </div>
  );
};

export default page;
