import { AllOrders } from "@/components/admin/orders/AllOrders";
import React from "react";

const page = () => {
  return (
    <div>
      <AllOrders />
    </div>
  );
};

export default page;
