import AddReviews from "@/components/admin/reviews/AddReviews";
import React from "react";

const page = () => {
  return (
    <div>
      <AddReviews />
    </div>
  );
};

export default page;
