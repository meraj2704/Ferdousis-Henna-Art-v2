import { AllReviews } from "@/components/admin/reviews/AllReviews";
import React from "react";

const page = () => {
  return (
    <div>
      <AllReviews />
    </div>
  );
};

export default page;
