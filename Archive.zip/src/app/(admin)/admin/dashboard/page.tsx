import Dashboard from "@/components/admin/dashboard/Dashboard";
import React from "react";

const page = () => {
  return (
    <div className="">
      <Dashboard />
    </div>
  );
};

export default page;
