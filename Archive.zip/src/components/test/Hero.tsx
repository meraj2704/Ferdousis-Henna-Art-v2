// import React from "react";
// import HeroCarousel from "./HeroCarousel";
// import styles from "./Hero.module.css";
// const Hero = () => {
//   return (
//     <div className="w-full h-[704px] relative">
//       <HeroCarousel />
//       <div
//         className={`${styles.gradientBackground} absolute w-full h-full inset-0 `}
//       >
//         <div className="container mx-auto text-7xl text-green-600 h-full flex flex-col justify-center items-start">
//           ATI Limited
//         </div>
//       </div>
//     </div>
//   );
// };
// export default Hero;